<h1>Tableau de bord Administrateur</h1>

<a href="index.php?controller=Admin&action=gestionUtilisateurs" style="color: black;">Gestion des Utilisateurs</a><br>
<a href="index.php?controller=Admin&action=displayAllEvenement" style="color: black;">Gestion des Evénements</a><br><br>
<a href="index.php?controller=Accueil&action=home" style="color: red; font-size: 1.8rem;">Aller sur le site</a>