<footer>
    <div class="footer-container">
        <div class="footer-content">
            <p>&copy; SMF2025. All rights reserved.</p>
            <nav class="footer-links">
                <a href="#">Privacy Policy</a>
                <a href="#">Terms of Service</a>
                <a href="index.php?controller=Contact&action=showContactForm">Contact Us</a>
            </nav>
        </div>
    </div>
</footer>
<script src="script.js"></script>
</body>

</html